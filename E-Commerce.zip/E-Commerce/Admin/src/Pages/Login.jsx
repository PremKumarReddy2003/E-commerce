import React from 'react'

const Login = () => {
  return (
    <div className='login'>
      
    </div>
  )
}

export default Login
